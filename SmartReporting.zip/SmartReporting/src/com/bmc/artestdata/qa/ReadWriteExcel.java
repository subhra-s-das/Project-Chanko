package com.bmc.artestdata.qa;

public class ReadWriteExcel {

	public static void main(String[] args) {
	
		
		

	}

}
