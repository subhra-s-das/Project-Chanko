package com.bmc.jdbcautomation.qa;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.beust.testng.TestNG;

public class verifyQuery {


	// Setup the jdbc connection parameters
	public String juser="peter";
	public String jurl="jdbc:arserver://vw-pun-atm-dv18:0;mode=new";
	public String jpassword="bmcAdm1n";
	public Connection jconn;
	public String jsql =null;
	public Map<String, String> jhashmap;
	public Statement jst = null;
	ResultSet jrs = null;
	
	//Set up the native SQL Server/ Oracle connection parameters
	public String nuser="ARAdmin";
	public String nurl="jdbc:sqlserver://vw-pun-atm-dv18:1433;databasename=ARSystem";
	public String npassword="AR#Admin#";
	public Connection nconn;
	public String nsql =null;
	public Map<String, String> nhashmap;
	public Statement nst = null;
	ResultSet nrs = null;

	@BeforeClass
	public void createConnections() {
		// Read the excel workbook for JDBC queries
		try {
			Workbook jworkbook = Workbook.getWorkbook(new File("src/Query.xls"));
			Sheet jsheet = jworkbook.getSheet(0);
			int jrowCount=jsheet.getRows();	// no of rows in excel
			jhashmap = new HashMap<String, String>();
			for (int i=0;i<jrowCount;i++)
			{	Cell jrowObj1 =jsheet.getCell(0, i);		// Cell interface , Sheet Interface
			Cell jrowObj2 =jsheet.getCell(1, i);
			//			System.out.println("Row Object_01 : "+jrowObj1.getContents());
			//			System.out.println("Row Object_02 : "+jrowObj2.getContents());
			jsql =jrowObj2.getContents();
			jhashmap.put(jrowObj1.getContents(), jrowObj2.getContents());
			}


			// Read the excel workbook for native SQL queries		
			Workbook nworkbook = Workbook.getWorkbook(new File("src/Query.xls"));
			Sheet nsheet = nworkbook.getSheet(1);
			int nrowCount=nsheet.getRows();	// no of rows in excel
			System.out.println("Executing Total: "+nrowCount+" Test Cases ......");
			System.out.println("--------------------------------------------------------------------------");
			nhashmap = new HashMap<String, String>();
			for (int i=0;i<nrowCount;i++)
			{	Cell nrowObj1 =nsheet.getCell(0, i);		// Cell interface , Sheet Interface
			Cell nrowObj2 = nsheet.getCell(1, i);
			//			System.out.println("Row Object_01 : "+nrowObj1.getContents());
			//			System.out.println("Row Object_02 : "+nrowObj2.getContents());
			nsql =nrowObj2.getContents();
//			System.out.println(nsql);
			nhashmap.put(nrowObj1.getContents(), nrowObj2.getContents());
//			System.out.println(nhashmap);	
			}
			
			//load the AR JDBC driver
			Class.forName("com.bmc.arsys.jdbc.core.Driver");
//			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			jconn = DriverManager.getConnection(jurl, juser, jpassword);
			jst = jconn.createStatement();
//			ResultSet jrs = jst.executeQuery(jsql);

			//load the MS SQL Server/ Oracle JDBC driver
			Class.forName("com.bmc.arsys.jdbc.core.Driver");
//			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
			nconn = DriverManager.getConnection(nurl, nuser, npassword);
			nst = nconn.createStatement();
//			ResultSet nrs = nst.executeQuery(nsql);
			
			
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@Test
	public void f() {
		
		String tc = "1";
		try {
			Assert.assertTrue(verifyResults(tc));
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	
	public boolean verifyResults (String testcaseID) throws SQLException {
		
		jsql =jhashmap.get(testcaseID);
		nsql =nhashmap.get(testcaseID);
		
		jrs = jst.executeQuery(jsql);
		nrs = nst.executeQuery(nsql);
		
		ResultSetMetaData jmetadata = jrs.getMetaData();
		ResultSetMetaData nmetadata = nrs.getMetaData();
		
		//get the column count of bot rs
		int jColCount = jmetadata.getColumnCount();
		int nColCount = nmetadata.getColumnCount();
		
		
		// add the SQL output to hashmap
		ArrayList<String> jsqlarray2 = new ArrayList<String>();
		ArrayList<String> nsqlarray2 = new ArrayList<String>();
		

		HashMap<Integer, ArrayList<String>> jhashMap2 = new HashMap<Integer, ArrayList<String>>();
		HashMap<Integer, ArrayList<String>> nhashMap2 = new HashMap<Integer, ArrayList<String>>();

				
		while (jrs.next())
		{
			int k;
			for (k=1;k<=jColCount;k++)
			{	
				jsqlarray2.add(jrs.getString(k));
				jhashMap2.put(1, jsqlarray2);
			}
			}
		
		// replace "null" to ... into jsqlarray elements
		for (int lj=0;lj<jsqlarray2.size();lj++)
		{
			String LJ = jsqlarray2.get(lj);
			if (LJ == "null")
			{
				jsqlarray2.set(lj, "NULL");
			}
		}
		
		ArrayList<String> jfinalResult = jhashMap2.get(1);
							System.out.println(jfinalResult);
		
		while (nrs.next())
		{
			int k;
			for (k=1;k<=nColCount;k++)
			{
		nsqlarray2.add(nrs.getString(k));
		nhashMap2.put(1, nsqlarray2);
				
			}
			}
		
//		 replace "null" to ... into jsqlarray elements
		for (int ln=0;ln<nsqlarray2.size();ln++)
		{
			String LN = nsqlarray2.get(ln);
			if (LN ==null)
			{
				nsqlarray2.set(ln, "NULL");
			}
		}
		
		
		ArrayList<String> nfinalResult = nhashMap2.get(1);
		System.out.println(nfinalResult);
		
		if (jfinalResult == null)
		{
			System.out.println("No Data In AR System For This Report To Display");
			return false;
		}
		
		if (nfinalResult == null)
		{
			System.out.println("No Data In AR System For This Query");
			return false;
		}
		
		else
		{
		if (jfinalResult.equals(nfinalResult))
		{
//			System.out.println("Test Case Number:"+i+" PASS");
			return true;
		}
		else 
		{
			return false;
		}
		
		}
		
	}

	
	
}
