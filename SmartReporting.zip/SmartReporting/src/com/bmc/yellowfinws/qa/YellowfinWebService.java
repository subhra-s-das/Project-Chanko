package com.bmc.yellowfinws.qa;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import com.gargoylesoftware.htmlunit.javascript.host.fetch.Request;
import com.hof.mi.web.service.ReportBinaryObject;
import com.hof.mi.web.service.ReportRow;
import com.hof.mi.web.service.ReportSchema;
import com.hof.mi.web.service.ReportServiceRequest;
import com.hof.mi.web.service.ReportServiceResponse;
import com.hof.mi.web.service.ReportServiceService;
import com.hof.mi.web.service.ReportServiceServiceLocator;
import com.hof.mi.web.service.ReportServiceSoapBindingStub;

public class YellowfinWebService {

	public static void main(String[] args) {

		String username = "siadmin";
		String password = "siadmin";
		int reportID = 58966;
		connection conn = new connection();
		ReportServiceSoapBindingStub repocall = conn.conn("clm-pun-015281", 94,
				"/services/ReportService");

		ReportServiceRequest rsr = new ReportServiceRequest();
		rsr.setLoginId(username);
		rsr.setPassword(password);
//		rsr.setReportUserId(username);
//		rsr.setReportUserPassword(password);
		// rsr.setOrgRef("bmc");
		rsr.setOrgId(new Integer(1));
		rsr.setReportRequest("RESULTSET");
		rsr.setReportId(reportID);

		try {
			ReportServiceResponse response = repocall.remoteReportCall(rsr);
			System.out.println("Status Code " + response.getStatusCode());

			ReportRow[] results = response.getResults();
			System.out.println(results.length);

			for (int i = 0; i < results.length; i++) {
				String[] value = results[i].getDataValue();
				for (int k = 0; k < value.length; k++) {

					System.out.println(value[k]);
				}

			}
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}

class connection {

	public ReportServiceSoapBindingStub conn(String hostname, int port,
			String serviceName) {
		ReportServiceService reportService = new ReportServiceServiceLocator(
				hostname, port, serviceName, false);
		ReportServiceSoapBindingStub rssbs = null;
		try {
			rssbs = (ReportServiceSoapBindingStub) reportService
					.getReportService();
		} catch (ServiceException e) {
			e.printStackTrace();
		}
		return rssbs;

	}

}
