package com.bmc.yellowfinws.qa;

public class ReportService {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
