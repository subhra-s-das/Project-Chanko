package UserData;
import com.bmc.arsys.api.ARServerUser;



public class mspMain {
	public static void main(String[] args) {

		ARServerUser arserver = new ARServerUser();
		

		
	}

}
